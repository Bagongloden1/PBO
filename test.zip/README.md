# Aplikasi Penjualan Toko dengan PyQt5 dan MySQL

Aplikasi ini dibuat oleh Andreas Abi Permana untuk memenuhi tugas UAS mata kuliah Pemrograman Plathform Independen. Aplikasi ini dibuat menggunakan PyQt5 dengan IDE QT Creator.

## Library Python3 yang digunakan 
 - mysql.connector

## Paduan penggunaan aplikasi.
1. Install Qt Creator 5
2. Install XAMPP / LAMPP
3. Import Database pada direktori SQL
4. Jalankan aplikasi melalui Qt Creator 5
5. Untuk melakukan kompilasi aplikasi gunakan aplikasi pyinstaller

